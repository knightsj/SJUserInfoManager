//
//  DataListTableViewController.h
//  SJFMDBDemo
//
//  Created by SHIJIE on 2016/10/9.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DataListTableViewController : UITableViewController

@property (nonatomic, strong) NSDictionary *userInfosDict;

@end

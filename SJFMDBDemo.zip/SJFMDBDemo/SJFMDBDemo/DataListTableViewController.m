//
//  DataListTableViewController.m
//  SJFMDBDemo
//
//  Created by SHIJIE on 2016/10/9.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//

#import "DataListTableViewController.h"

@interface DataListTableViewController ()

@property (nonatomic, strong) NSArray *userInfosArray;

@end

@implementation DataListTableViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    NSString *alertTitle = [self.userInfosDict objectForKey:@"result"];
    [self showAlertWithTitle:alertTitle];
    
    NSArray *userInfosArray = [self.userInfosDict objectForKey:@"userInfosArray"];
    if ([userInfosArray count] != 0) {
         self.userInfosArray = userInfosArray;
        [self.tableView reloadData];
    }
    
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.userInfosArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *cellID = @"dataListCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    NSDictionary *userInfoDict = self.userInfosArray[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"UserName: %@",[userInfoDict objectForKey:@"user_name"]];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"UserID: %@",[userInfoDict objectForKey:@"user_id"]];
    
    return cell;
}

- (void)showAlertWithTitle:(NSString *)title
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:@"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}




@end

//
//  ViewController.m
//  SJFMDBDemo
//
//  Created by SHIJIE on 2016/10/9.
//  Copyright © 2016年 SHIJIE. All rights reserved.
//


#import "ViewController.h"
#import "SJUserInfoManager.h"
#import "DataListTableViewController.h"


#define DATABASENAME @"userInfoTable"
#define USERINFOFIELD @"user_name"

@interface ViewController ()

@property (strong, nonatomic) IBOutlet UITextField *insertUserIdTextfield;
@property (strong, nonatomic) IBOutlet UITextField *insertUserInfoValueTextfiled;

@property (strong, nonatomic) IBOutlet UITextField *queryUserIdTextfield;
@property (strong, nonatomic) IBOutlet UILabel *queryUserInfoValueLabel;

@property (strong, nonatomic) IBOutlet UITextField *deleteUserIdTextField;

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    BOOL hasCreated = [SJUserInfoManager createDataBaseWithName:DATABASENAME andUserInfoField:USERINFOFIELD];
    NSString *result = @"";
    
    if (hasCreated) {
        
        result = @"Database created successfully";
        
    }else{
        
        result = @"Database created failded";
        
    }
    
    [self showAlertWithTitle:result];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
}

- (IBAction)insertAction:(id)sender {
   
    NSString *result = @"";
    
    if (self.insertUserInfoValueTextfiled.text.length == 0) {
        
         result = @"Please Input UserID!";
        
    }else{
        
         result = [SJUserInfoManager updateUserInfoIntoDataBase:DATABASENAME withUserID:self.insertUserIdTextfield.text andUserInfoField:USERINFOFIELD andUserInfoValue:self.insertUserInfoValueTextfiled.text];
    }
   
   [self showAlertWithTitle:result];
    
}

- (IBAction)queryUserInfoValue:(UIButton *)sender {
    
    NSString *result = @"";
    
    if (self.queryUserIdTextfield.text.length == 0) {
        
        result = @"Please Input UserID!";
        self.queryUserInfoValueLabel.text = @"";
        
    }else{
        
        result =  [SJUserInfoManager queryUserInfoInDataBase:DATABASENAME WithUserID:self.queryUserIdTextfield.text andUserInfoField:USERINFOFIELD];
        self.queryUserInfoValueLabel.text = result;
        [self showAlertWithTitle:result];
        
    }
    
    [self showAlertWithTitle:result];
}



- (IBAction)deleteUserInfoWithUserID:(UIButton *)sender {
    
    NSString *result = @"";
    
    if (self.deleteUserIdTextField.text.length == 0) {
        
        result = @"Please Input UserID!";
        
    }else{
        
        result =  [SJUserInfoManager deleteUserInfoInDataBase:DATABASENAME WithUserID:self.deleteUserIdTextField.text];
    }
    
    [self showAlertWithTitle:result];
    
}

- (void)showAlertWithTitle:(NSString *)title
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:@"" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self.insertUserIdTextfield resignFirstResponder];
        [self.insertUserInfoValueTextfiled resignFirstResponder];
        [self.queryUserIdTextfield resignFirstResponder];
        [self.deleteUserIdTextField resignFirstResponder];
        
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[DataListTableViewController class]]) {
        if ([segue.identifier isEqualToString:@"userInfosList"]) {
            
            NSDictionary *userInfosDict = [SJUserInfoManager queryUserInfosInDataBase:DATABASENAME andUserInfoField:USERINFOFIELD];
            DataListTableViewController *dataListVc = (DataListTableViewController *)segue.destinationViewController;
            dataListVc.userInfosDict = userInfosDict;
        }
    }
    
}
@end
